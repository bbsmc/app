![labrinth banner](https://user-images.githubusercontent.com/12068027/100479891-d6bab300-30ac-11eb-8336-b4cad376a03d.png)

## Modrinth's laboratory for its backend service & API!

For contributing information, please see the labrinth section of the [Modrinth contributing guide](https://docs.modrinth.com/contributing/labrinth/). For documentation on the API itself, see the [API Spec](https://docs.modrinth.com/api/).
